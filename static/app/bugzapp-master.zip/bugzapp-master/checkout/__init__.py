default_app_config = 'checkout.apps.CheckoutConfig'
